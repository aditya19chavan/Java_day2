package generics;

class MyClass {
	// Generic method to print array with diff data type

	public <E> void printArray(E[] arr1) {
		for (E i : arr1) {
			System.out.println(i);
		}
		System.out.println("=====================");
	}
}

public class GenericDemo {

	public static void main(String[] args) {
		MyClass myclass = new MyClass();
//pass the Integer array
		Integer[] arrInt = { 11, 22, 33, 44, 55 };
		myclass.printArray(arrInt);

		Double[] arrDouble = { 10.20, 22.33, 10.45, 8.06 };
		myclass.printArray(arrDouble);

		Character[] arrchar = { 'A', 'D', 'I', 'T', 'Y', 'A' };
		myclass.printArray(arrchar);
         
		Long[] arrlong = { 12047453323l, 13145634668l,121423545l };
		myclass.printArray(arrlong);
		
		String[] arrString = {"Aditya","Shreyas", "ashish"};
		myclass.printArray(arrString);
		
	}

}
