package enum1;

import java.util.Iterator;

interface Interface1 {
	String comp = "OFS";

	void fun1();

	void fun2();

	void fun3();

	void fun4();

}

enum Month implements Interface1 {
	JAN, FEB, MAR, APR, MAY;

	public void fun1() {

		System.out.println("This is fun1 ");
	}

	public void fun2() {
		System.out.println("This is fun2");
	}

	public void fun3() {
		System.out.println("This is fun3");
	}

	public void fun4() {
		System.out.println("This is fun4");
	}

} // 1 method

public class EnumDemo1 {
//	enum Month {
//		JAN, FEB, MAR, APR, MAY;
//
//	}//2 method
	public static void main(String[] args) {
//		enum Month {
//			JAN, FEB, MAR, APR, MAY;
//
//		} // 3 method
		Month m = Month.JAN;
		Month n = Month.FEB;
		Month o = Month.MAR;
		Month p = Month.APR;
		Month q = Month.MAY;

		// int a = 100;

		// calling the function
		// D //v
		m.fun1();
		n.fun2();
		o.fun3();
		p.fun4();
		q.fun4();

		System.out.println(Month.JAN);
		System.out.println(Month.MAY);
		System.out.println(Month.comp);
		System.out.println("m is " + m);
		System.out.println("n is " + n);
		System.out.println("o is " + o);
		System.out.println("p is " + p);
		System.out.println("q is " + q);
		
		System.out.println("=====================");
		System.out.println("Displaying values using enhanced for loop");
		for(Month mm: Month.values()){
			System.out.println(mm);
		}
		System.out.println("=====================");
	}

}
