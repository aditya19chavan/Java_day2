package enum1;

enum Week {
	Mon, Tue, Wed, Thu, Fri, Sat, Sun;
}

public class WeekDemo {

	public static void main(String[] args) {

		Week a = Week.Mon;
		Week b = Week.Tue;
		switch (b) {
		case Mon:
			System.out.println("Monday blues :( ");
			break;
		case Tue:
			System.out.println("A wonderful Tuesday ");
			break;
		case Wed:
			System.out.println("Lets us complete");
			break;
		case Thu:
			System.out.println("A good day of week");
			break;
		case Fri:
			System.out.println("Weekat at it's peak");
			break;
		case Sat:
			System.out.println("weekend started");
			break;
		case Sun:
			System.out.println("It's a sunday");
			break;
		default:
			System.out.println("Invalid entry");
		}

		System.out.println("============================");

		for (Week mm : Week.values()) {
			System.out.println(mm);
		}

	}

}
