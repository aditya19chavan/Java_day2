package enum1;

enum Month1 {
	JAN, FEB, MAR, APR, MAY;
}

public class EnumDemo2 {

	public static void main(String[] args) {
		Month1 m = Month1.JAN;

		System.out.println(m);

		switch (m) {
		case JAN:
			System.out.println("First month of year");
			break;
		case FEB:
			System.out.println("A wonderful month");
			break;
		case MAR:
			System.out.println("Lets us complete");
			break;
		case APR:
			System.out.println("A good month of summer");
			break;
		case MAY:
			System.out.println("Summer at it's peak");
			break;

		}

	}

}
