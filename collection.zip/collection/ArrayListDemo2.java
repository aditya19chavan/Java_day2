package collection;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListDemo2 {

	public static void main(String[] args) {
		// heterogenous collection
		ArrayList arraylist = new ArrayList();
		arraylist.add(10);
		arraylist.add(20.22);
		arraylist.add(true);
		arraylist.add("Aditya");

		EmployeeClass emp2 = new EmployeeClass(2, "Adi", 53000);
		EmployeeClass emp3 = new EmployeeClass(3, "ditya", 50070);

		arraylist.add(emp2);
		arraylist.add(emp3);

		// to display the object
		for (int i = 0; i < arraylist.size(); i++) { // homogenous collection
			System.out.println(arraylist.get(i));
			System.out.println("=========================");
		}

		// 2nd: to display the objects                                    //heterogenous collection
		System.out.println("using the iterator method");
		Iterator itr = arraylist.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
			System.out.println("=========================");
		}
		// to check wheather the obj is present : returns t/f
		boolean res = arraylist.contains("Aditya");
		System.out.println(res);

		// returns the int if present, else -1
		int res1 = arraylist.indexOf("Aditya");
		System.out.println("index of:" + res1);

		System.out.println("using the remove ");
		arraylist.remove("Aditya"); // using the obj
		arraylist.remove(1); // using the index

		for (int i = 0; i < arraylist.size(); i++) {
			System.out.println(arraylist.get(i));
			System.out.println("==========================");
		}

		// to delete all the elements
		arraylist.clear();
		System.out.println(arraylist.isEmpty()); // t/f

		arraylist.addFirst(22);
		arraylist.addLast(26);

		// to change the obj

		arraylist.set(1, 88);
		System.out.println("==========================");
		for (int i = 0; i < arraylist.size(); i++) {
			System.out.println(arraylist.get(i));
			System.out.println("==========================");
		}

	}

}
