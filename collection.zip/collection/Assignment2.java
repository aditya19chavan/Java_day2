package collection;

import java.util.ArrayList;
import java.util.Iterator;

class Account {
	private int accNo;
	private String name;
	private double balance;

	public Account(int accNo, String name, double balance) {
		super();
		this.accNo = accNo;
		this.name = name;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accNo=" + accNo + ", name=" + name + ", balance=" + balance + "]";
	}

}

public class Assignment2 {

	public static void main(String[] args) {

		ArrayList arraylist = new ArrayList();

		Account acc = new Account(1, "Aditya", 50000);
		Account acc1 = new Account(2, "shreyas", 30000);
		Account acc2 = new Account(3, "sonali", 53000);
		Account acc3 = new Account(4, "sunil", 22000);
		Account acc4 = new Account(5, "Adi", 12000);

		arraylist.add(acc);
		arraylist.add(acc1);
		arraylist.add(acc2);
		arraylist.add(acc3);
		arraylist.add(acc4);
		for (int i = 0; i < arraylist.size(); i++) { // homogenous collection
			System.out.println(arraylist.get(i));
			System.out.println("=========================");
		}

	}

}
