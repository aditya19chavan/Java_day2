package collection;

import java.util.Hashtable;

public class HashTableDemo {

	public static void main(String[] args) {
	/*	Hashtable<Integer, String> table1 = new Hashtable<Integer, String>();

		table1.put(1, "Ankit");
		table1.put(2, "Aditya");
		table1.put(3, "Yash");
		table1.put(4, "Ankita");
		table1.put(4, "Ram");

		System.out.println(table1.get(2));     */
		
		Hashtable<Character, String> table2 = new Hashtable<Character, String>();

		table2.put('A', "Ankit");
		table2.put('A', "Aditya");
		table2.put('Y', "Yash");
		table2.put('A', "Ankita");
		table2.put('R', "Ram");
		
		System.out.println(table2);
		System.out.println(table2.clone());
	}


}
