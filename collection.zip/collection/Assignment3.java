package collection;

import java.util.ArrayList;

public class Assignment3 {
	class Account {
		private int accNo;
		private String accName;

		public Account(int accNo, String accName) {
			super();
			this.accNo = accNo;
			this.accName = accName;

		}

		

		@Override
		public String toString() {
			return "Account [accNo=" + accNo + ", accName=" + accName + "]";
		}



		class Emp {

			private String name;
			private double salary;
			private int empNo;

			@Override
			public String toString() {
				return "Emp [name=" + name + ", salary=" + salary + ", empNo=" + empNo + "]";
			}

		}

	}

	public static void main(String[] args) {
		ArrayList arraylist = new ArrayList();
        Account acc=new Account(1, "Saving");
	}

}
