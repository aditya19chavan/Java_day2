package collection;

import java.util.Iterator;
import java.util.TreeSet;

public class TreeSetDemo {

	public static void main(String[] args) {
		// collection of Integers array
		TreeSet<Integer> tree1 = new TreeSet<Integer>();
		// TreeSet<Double> tree1=new TreeSet<Double>();
		tree1.add(10);
		tree1.add(20);
		tree1.add(40);
		tree1.add(30);
		tree1.add(56);
		// tree1.add(10.77);

		System.out.println("size is: " + tree1.size());
		System.out.println("=======================");
		
		System.out.println("using iterator");
		Iterator itr = tree1.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		System.out.println("=======================");
		
		
		System.out.println("using sop");
		System.out.println(tree1);
		System.out.println("=======================");
		System.out.println("remove 10");
		tree1.remove(10);
		System.out.println(tree1);
		System.out.println("=======================");
		System.out.println("clear all elements");
		tree1.clear();
		System.out.println(tree1);
	}

}
