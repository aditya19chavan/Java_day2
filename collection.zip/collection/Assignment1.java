//create a function to display the sum of first 10 prime numbers,create another function to display
//the natural numbers between 20 to 30 create 2 threads to call the functions use synchronized


package collection;

import java.util.TreeSet;

public class Assignment1 {

	public static void main(String[] args) {
		int n;
		int sum=0;
		TreeSet<Integer> num1 = new TreeSet<Integer>();
		
		

	}

}
