package collection;

import java.util.ArrayList;

import inheritance.Emp;

public class ArrayListDemo {

	public static void main(String[] args) {
		//ArrayList arraylist = new ArrayList();
		ArrayList<EmployeeClass > arraylist=new ArrayList<EmployeeClass >();

//creating objects of Emp

		EmployeeClass emp1 = new EmployeeClass(1, "Aditya", 50000);
		EmployeeClass emp2 = new EmployeeClass(2, "Adi", 53000);
		EmployeeClass emp3 = new EmployeeClass(3, "ditya", 50070);

		arraylist.add(emp1);
		arraylist.add(emp2);
		arraylist.add(emp3);

		for (int i = 0; i < arraylist.size(); i++) {
			System.out.println(arraylist.get(i));
			System.out.println("=========================");
		}

	}

}
