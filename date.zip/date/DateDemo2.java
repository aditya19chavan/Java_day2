package date;

import java.util.Date;
import java.text.*;

public class DateDemo2 {

	public static void main(String[] args) {
		Date d1=new Date();
		System.out.println(d1);

		//to format the date
		SimpleDateFormat sdf=new SimpleDateFormat("E yyyy.MM.dd ' at ' hh:mm:ss a");
		//SimpleDateFormat sdf=new SimpleDateFormat("D yyyy.MM.dd ' at ' hh:mm:ss a");
		//class           obj                        format
		System.out.println("date is " + sdf.format(d1));
		
		System.out.println("===================================================");
		
		SimpleDateFormat sdf1=new SimpleDateFormat("yyyy 'year' ");
		SimpleDateFormat sdf2=new SimpleDateFormat("MM 'month' ");
		SimpleDateFormat sdf3=new SimpleDateFormat("dd 'date' ");
		
		System.out.println("date is " +sdf1.format(d1));
		System.out.println("date is "+sdf2.format(d1));
		System.out.println("date is "+sdf3.format(d1));
		
		System.out.println("===================================================");
		
		
	}

}
