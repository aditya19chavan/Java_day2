package date;

import java.util.Date;

public class DateDemo {

	public static void main(String[] args) {
	Date d = new Date();
	System.out.println(d);

	}

}
