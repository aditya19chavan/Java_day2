package date;

import java.text.SimpleDateFormat;
import java.util.Date;

public class DateDemo3 {

	public static void main(String[] args) {
	
		Date d = new Date();
		System.out.println(d);
     
		
		
		SimpleDateFormat sdf=new SimpleDateFormat(" dd/MM/yyyy");  //9/10/24
		System.out.println("Date: " +sdf.format(d));
		
		SimpleDateFormat sdf3=new SimpleDateFormat(" d MMM Y  ");  // 9 oct2024
		System.out.println("Date: " +sdf3.format(d));
		
		SimpleDateFormat sdf1=new SimpleDateFormat(" d MMM Y  'time' a");  // 9 oct2024 time 
		System.out.println("Date: " +sdf1.format(d));
		
		SimpleDateFormat sdf2=new SimpleDateFormat(" d MMMM Y");  // 9 october 2024
		System.out.println("Date: " +sdf2.format(d));
		
		SimpleDateFormat sdf4=new SimpleDateFormat("z d MMMM Y");  
		System.out.println("Time zone: " +sdf4.format(d));
	}

}
