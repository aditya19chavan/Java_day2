package userinterface;

import java.util.Scanner;
import entity.Account;
import operations.AccountOperation;

public class TestAccount {

	public static void main(String[] args) {

		Account account1 = new Account(1, "Aditya", 55555);
		Account account2 = new Account(1, "Pratik", 40000);
		AccountOperation accountoperation = new AccountOperation();

		int ch;
		String choice;
		Scanner sc = new Scanner(System.in);

		do {

			System.out.println("Welcome to ICICI Bank");
			System.out.println("1. Accept Details");
			System.out.println("2. Display Details");
			System.out.println("3. Withdraw Amount");
			System.out.println("4. Deposit Amount");
			System.out.println("5. Transfer Amount");
			System.out.println("6. Check Balance");
			System.out.println("7. Update Balance");
			System.out.println("8. Exit");

			System.out.println("Enter your choice:");
			ch = sc.nextInt();

			switch (ch) {
			case 1:
				System.out.println("Accepting account details");
				break;
			case 2:
				System.out.println("Displaying the details");
				System.out.println("account number is: " + account1.getAccNo());
				System.out.println("name is:" + account1.getAccHolderName());
				System.out.println("balance is: " + account1.getBalance());
				break;
			case 3:
				System.out.println("Enter the withdrawing amount...");
				double amount = sc.nextDouble();
				boolean result = accountoperation.withdraw(account1, amount);
				if (result == true) {
					System.out.println("Withdraw is successful");
					System.out.println("The new balance is:" + account1.getBalance());
					
				}

				else
					System.out.println("Withdraw is fail");
				System.out.println("===========================================");

				break;
			case 4:
				System.out.println("Depositing amount");
				System.out.println("Enter the depositing amount...");
				amount = sc.nextDouble();
				result = accountoperation.deposit(account1, amount);
				if (result == true) {
					System.out.println("Deposit successful..");
					System.out.println("The new balance is: " + account1.getBalance());
				
				} else {
					System.out.println("Deposit failed..");
					System.out.println("=========================================");
				}

				break;

			case 5:
				System.out.println("Transferring the amount");
				System.out.println("Enter the  transferring amount");
				amount = sc.nextDouble();
				System.out.println("The old balance of account1 is: " + account1.getBalance());
				System.out.println("The old balance of account2 is: " + account2.getBalance());
				result = accountoperation.transfer(account1, account2, amount);
				if (result == true) {
					System.out.println("Transfer successful..");
					System.out.println("The new balance of account1 is: " + account1.getBalance());
					System.out.println("The new balance of account2 is: " + account2.getBalance());
					
				} else {
					System.out.println("Transfer Failed...");
					System.out.println("================================================");
				}
				break;

			case 6:
				System.out.println("Checking the balance");
				System.out.println("The new balance of account1 is: " + account1.getBalance());
				System.out.println("The new balance of account2 is: " + account2.getBalance());
				
				break;
			case 7:
				System.out.println("Updating the balance");
				break;
			case 8:
				System.out.println("Thank you for visiting...!!!");
				System.exit(0);

			}
			System.out.println("Do you want to continue(y/n)");
			choice = sc.next();
		} while (choice.equalsIgnoreCase("Y"));
		System.out.println("Thank you for visiting...!!!");
	}

}
