package composition;

import java.util.ArrayList;
import java.util.List;

class Book {
	public String title;
	public String author;

	Book(String title, String author) {
		this.title = title;
		this.author = author;
	}
}

class Library {
	private final List<Book> books;
//           datatype        variable 
	Library(List<Book> books) {
		this.books = books;
	}

	public List<Book> getTotalBooksInLibrary() {
		return books;
	}
}

public class CompositionDemo {

	public static void main(String[] args) {
		// creating  the book objects
		Book b1 = new Book("3 mistakes of my life", "Chetan Bhagat");
		Book b2 = new Book("5 point someone", "Chetan Bhagat");
		Book b3 = new Book("CHAVA ", "Sawant");
		Book b4 = new Book("Alchemist ", "Paulo coelho");
		Book b5 = new Book("Rich dad poor dad ", "Robert kiyosaki");
		Book b6 = new Book("Zero to one", "Peter Thiel");

		// adding the objects into the collection

		List<Book> books = new ArrayList<Book>();
		books.add(b1);
		books.add(b2);
		books.add(b3);
		books.add(b4);
		books.add(b5);
		books.add(b6);

		// creating the library obj1 with books collection
		Library library = new Library(books);

		List<Book> bks = library.getTotalBooksInLibrary();

		for (Book bk : bks) {
			System.out.println("Title: " + bk.title + " and " + " Author :" + bk.author);
		}
	}

}
