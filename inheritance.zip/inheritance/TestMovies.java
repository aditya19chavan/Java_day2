package inheritance;

public class TestMovies {

	public static void main(String[] args) {
	Movies movies = new Movies("Action", 300000.0, 256);
	System.out.println(movies);
	
	System.out.println("==========================================================================================");
	
	Hollywood hollywood=new Hollywood("Action", 300000.0, 256, "Inception", "C Nolon", 456000000.00, "English");
	System.out.println(hollywood);
	
	System.out.println("==========================================================================================");
	Indian indian =new Indian("Action", 300000.0, 256, "Inception", "C Nolon", 456000000.00, "English" ,"marathi", 5, 21);
	System.out.println(indian);
	
	}

}
