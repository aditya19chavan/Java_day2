package inheritance;

public class Movies {
	
protected String genre;
protected double boCollection;
protected int screenAva;

public Movies(String genre, double boCollection, int screenAva) {
	super();
	this.genre = genre;
	this.boCollection = boCollection;
	this.screenAva = screenAva;
}
@Override
public String toString() {
	return "Movies [genre=" + genre + ", boCollection=" + boCollection + ", screenAva=" + screenAva + "]";
}










}
