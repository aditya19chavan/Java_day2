package inheritance;

public class Emp extends Student{

private String name;
private int EmpId;
private double salary;

public Emp(String name, int age, char gender, int rollNo, String stream, double score, String name2, int empId,
		double salary) {
	super(name, age, gender, rollNo, stream, score);
	name = name2;
	EmpId = empId;
	this.salary = salary;
}

public void display() {
	super.display();    //calling the method of parent class
	super.fun1();
}

@Override
public String toString() {
	return "Emp [name=" + name + ", EmpId=" + EmpId + ", salary=" + salary + ", rollNo=" + rollNo + ", stream=" + stream
			+ ", score=" + score + ", age=" + age + ", gender=" + gender + "]";
}




}
