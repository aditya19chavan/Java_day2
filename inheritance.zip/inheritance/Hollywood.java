package inheritance;

public class Hollywood extends Movies {
	
protected String name;
protected String director;
protected double budget;
protected String language;

public Hollywood(String genre, double boCollection, int screenAva, String name, String director, double budget,
		String language) {
	super(genre, boCollection, screenAva);
	this.name = name;
	this.director = director;
	this.budget = budget;
	this.language = language;
}
@Override
public String toString() {
	return "Hollywood [name=" + name + ", director=" + director + ", budget=" + budget + ", language=" + language
			+ ", genre=" + genre + ", boCollection=" + boCollection + ", screenAva=" + screenAva + "]";
}




}
