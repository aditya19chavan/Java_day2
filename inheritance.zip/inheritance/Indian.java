package inheritance;

public class Indian extends Hollywood {

	protected String region;
	protected double regionalLang;
	protected int noOfactors;
	public Indian(String genre, double boCollection, int screenAva, String name, String director, double budget,
			String language, String region, double regionalLang, int noOfactors) {
		super(genre, boCollection, screenAva, name, director, budget, language);
		this.region = region;
		this.regionalLang = regionalLang;
		this.noOfactors = noOfactors;
	}
	@Override
	public String toString() {
		return "Indian [region=" + region + ", regionalLang=" + regionalLang + ", noOfactors=" + noOfactors + ", name="
				+ name + ", director=" + director + ", budget=" + budget + ", language=" + language + ", genre=" + genre
				+ ", boCollection=" + boCollection + ", screenAva=" + screenAva + "]";
	}
	
	
}
