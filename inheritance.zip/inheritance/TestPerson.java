package inheritance;

public class TestPerson {

	public static void main(String[] args) {
		
		
		Person person = new Person("Aditya", 24, 'M');

		System.out.println(person);
		person.display();
		person.fun1();

		System.out.println("===============================================================================");

		Student student = new Student("Aditya", 24, 'M', 22, "ECE", 85.5);
		System.out.println(student);
		student.display();
		student.fun1();

		System.out.println("===============================================================================");
		Emp emp = new Emp("Aditya", 24, 'M', 22, "ECE", 85.5, "IT", 234, 35000);
		System.out.println(emp);
		student.display();
		student.fun1();

		System.out.println("=========================Binding================================================");

		Person person2 = new Person("Aditya", 24, 'M'); // parent class
		System.out.println(person2);

		person2 = new Student("Aditya", 24, 'M', 22, "ECE", 85.5);
		// p child----allowed
		System.out.println(person2);

		person2 = new Emp("Aditya", 24, 'M', 22, "ECE", 85.5, "IT", 234, 35000);
		System.out.println(person2);

	}

}
