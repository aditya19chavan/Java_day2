
// Creating an array of object

package inheritance;

public class TestPerson2 {

	public static void main(String[] args) {
		

		Person[] arr = new Person[5];

		arr[0] = new Person("Aditya", 24, 'M');
		arr[1] = new Person("Shreyas", 20, 'M');
		arr[2] = new Person("Aditi", 22, 'F');
		arr[3] = new Person("Ajay", 24, 'M');
		arr[4] = new Person("Rahul", 23, 'M');

		for (int i = 0; i < arr.length; i++) {
			//System.out.println(arr[i]);
			System.out.println(arr[i].getName() + " is " +arr[i].getAge() + " years old and gender is " +arr[i].getGender());
		}

	}

}
