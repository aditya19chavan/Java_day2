package Assignment_1;

public class BankB extends BankA {
	protected double accountbalance;

	public BankB(double accountbalance, double accountbalance2, double accountbalance3) {
		super(accountbalance, accountbalance2);
		accountbalance = accountbalance3;
	}

	@Override
	public String toString() {
		return "BankB [accountbalance=" + accountbalance + ", interest=" + interest + "]";
	}


	
	
}
