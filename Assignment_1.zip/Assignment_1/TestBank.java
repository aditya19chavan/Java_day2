package Assignment_1;

public class TestBank {

	public static void main(String[] args) {
		Bank bank=new Bank(0);
		BankA bankA=new BankA(1000, 0);
		BankB bankB=new BankB(0, 1000, 1500);
		BankC bankC=new BankC(0, 1000, 1500, 2000);
		
		System.out.println("balance is "+bank.getBalance());
		System.out.println("Balance of BankA is: "+bankA.getBalance());
		System.out.println("Balance of BankB is: "+bankB.getBalance());

	}

}
