package Assignment_1;

public class BankC extends BankB{
	protected double accountbalance;

	public BankC(double accountbalance, double accountbalance2, double accountbalance3, double accountbalance4) {
		super(accountbalance, accountbalance2, accountbalance3);
		accountbalance = accountbalance4;
	}

	@Override
	public String toString() {
		return "BankC [accountbalance=" + accountbalance + ", interest=" + interest + "]";
	}


	

}
