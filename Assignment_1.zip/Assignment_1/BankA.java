package Assignment_1;

public class BankA extends Bank{
	protected double amount;
	
	
	public double BankA(double amount) {
		return 0;
		
	}
	
	
	

	
	
	
	
	
	
}
