package Assignment_1;

public class Bank {
	
protected double accountbalance;
protected static double interest=0.6;

public Bank(double accountbalance) {
	
	this.accountbalance = accountbalance;
}





}


