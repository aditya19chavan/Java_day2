package lambda;

interface Interface3 {
	void absfun(int x, int y, int z);
}

public class Myclass3 {

	public static void main(String[] args) {
		Interface3 obj = (int x, int y, int z) -> {
			System.out.println("Multiplication is :" + (x * y * z));
			System.out.println("x square is: " + (x * x));
			System.out.println("sum of x,y and z is: " + (x + y + z));
			System.out.println("sum of squares of x,y and z :"+((x*x) + (y*y) +(z*z)));
		};
      obj.absfun(3, 4, 6);
	}

}
