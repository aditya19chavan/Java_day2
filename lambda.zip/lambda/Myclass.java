package lambda;

interface Interface1 {
	void absfun(int x,int y,int z); // abstract method

	default void fun1() { // non abstract method
		System.out.println("this is fun1");
	}
}

public class Myclass { //2

	public static void main(String[] args) {
           Interface1 fobj =(int x ,int y, int z) -> System.out.println(100 * x * y * z);
           fobj.absfun(3, 2, 4);
           fobj.absfun(5, 3, 2);
           fobj.absfun(5, 3, 6);
	}

}
