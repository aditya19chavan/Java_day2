package lambda;

interface Interface2 {
	void abscube(int x);
}

public class Myclass2 {
	public static void main(String[] args) {

		Interface2 fobj = (int x) -> System.out.println(x * x * x);
		fobj.abscube(3);
	}

}
