package lambda;

import java.util.Scanner;

interface Interface4 {
	void check(int x);

}

public class Myclass4 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		Interface4 obj = (int x) -> {
			if (x % 2 == 0) {
				System.out.println("It is a even number");
			} else {
				System.out.println("it is a odd number");
			}
		};
		System.out.println("Enter the number");
		int x=sc.nextInt();
		obj.check(4);
	}
}
