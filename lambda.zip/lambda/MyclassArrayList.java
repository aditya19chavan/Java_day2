package lambda;

import java.util.ArrayList;
import java.util.Scanner;

public class MyclassArrayList {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the size of array");
		int n = sc.nextInt();
		ArrayList<Integer> arrList = new ArrayList<Integer>();
		System.out.println("Enter the array elments:");
		for (int i = 0; i < n; i++) {
			
			arrList.add(sc.nextInt());
		}

//to display: 1st use of lambda expression
		arrList.forEach(i -> System.out.println(i));

//2nd use of lambda expression
		System.out.println("Displaying even numbers...");
		arrList.forEach(i -> {
			if (i % 2 == 0)
				System.out.println(" " + i);
		});

	}

}
