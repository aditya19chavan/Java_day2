package module6;

public class TestCustomer {

	public static void main(String[] args) {
	

	
	Customer customer=new Customer();
//	System.out.println("custId is:"+customer.getCustId());
//	System.out.println("name is:"+customer.getName());
//	System.out.println("mobile no:"+customer.getMobile());
//	System.out.println("address:"+customer.getAddress());
	
	System.out.println(customer);
	
	
	
	System.out.println("===================================");
	Customer customer1=new Customer(2,"aditya",98346056,"Parli");   //param cons
	System.out.println("Displaying the details");
	
	
//	System.out.println("custId is:"+customer1.getCustId());
//	System.out.println("name is:"+customer1.getName());
//	System.out.println("mobile no:"+customer1.getMobile());
//	System.out.println("address:"+customer1.getAddress());
	
	System.out.println(customer1);
	

	
	}

}
