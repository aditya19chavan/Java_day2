package module6;

import java.util.Scanner;

public class TestGetterSetter {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		System.out.println("enter rollno, name, score");
		int rollNo = sc.nextInt();
		String name = sc.next();
		double score = sc.nextDouble();

		GetterSetter student = new GetterSetter(); // call default constructor
		student.setRollNo(rollNo);
		student.setName(name);
		student.setScore(score);

		// student.display();
		System.out.println("Displaying the details..........");
		System.out.println("rollno is" + student.getRollNo());
		System.out.println("name is " + student.getName());
		System.out.println("score is " + student.getScore());
		student.markAttendence();

		System.out.println("====================================");
		System.out.println("Calling the param constructor..");
		GetterSetter student2 = new GetterSetter(rollNo, name, score);

		// student2.display();
		System.out.println("Displaying the details..........");
		System.out.println("rollno is" + student2.getRollNo());
		System.out.println("name is " + student2.getName());
		System.out.println("score is " + student2.getScore());

		student2.markAttendence();

		System.out.println("===============================");
		System.out.println("Changing the name");
		System.out.println("Enter the new name");
		String name1 = sc.next();
		student2.setName(name1); // .setName to set the value
		System.out.println("new name is: " + student2.getName());

	}

}
