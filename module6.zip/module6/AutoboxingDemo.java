package module6;

public class AutoboxingDemo {

	public static void main(String[] args) {
		int a=100;
		Integer i=a;   //autoboxing
		
		float b=100.30f;
		Float f=b;
		System.out.println(i.valueOf(a));
	
		System.out.println("========================");
		int a1=i;     //unboxing
		System.out.println("unboxing"+a1);

	}

}
