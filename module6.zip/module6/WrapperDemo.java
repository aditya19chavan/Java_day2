package module6;

public class WrapperDemo {

	public static void main(String[] args) {
	String str="100";
	String str1="200";
	String str2="200.50";
	String str3="120.45";
	String str4="123.70";
	String str5="135.50";
	String str6="aditya";
	String str7="Aditya";
	System.out.println("Int total is: "+(Integer.parseInt(str)+Integer.parseInt(str1)));
	
	
	System.out.println("=======================================");
	System.out.println("Double total is :"+(Double.parseDouble(str2)+Double.parseDouble(str3)));
	
	
	System.out.println("=======================================");
	System.out.println("Float total is :"+(Float.parseFloat(str4)+Float.parseFloat(str5)));
	
	System.out.println(Float.valueOf(str5));
	
	
	System.out.println("compare:"+Integer.compare(100, 50));
	System.out.println("Binary: "+Integer.toBinaryString(7));
	
	
	
	System.out.println(Byte.MAX_VALUE);
	System.out.println(Short.MAX_VALUE);
	System.out.println(Integer.MIN_VALUE);
	System.out.println(Long.MAX_VALUE);
	System.out.println(Byte.MIN_VALUE);
	

	}

}
