package module6;

public class TestAccount {

	public static void main(String[] args) {
		System.out.println("SBI Account Details ");
		Account account = new Account();
         account.setAccNo(123456);
         account.setAccName("Current");
         account.setAccBalance(2005700.50);
		System.out.println(account); // def cons
		
		System.out.println("============================================");

		Account account1 = new Account(12345, "Saving", 200000.50); // param cons
		System.out.println(account1);

	}

}
