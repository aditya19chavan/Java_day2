package module6;

public class TestStudent {

	public static void main(String[] args) {
		Student student=new Student();
		student.display();
		student.markAttendence();
		
		System.out.println("===================");
		Student student2=new Student(2,"Aditya_Chavan",90.50);
		System.out.println("object with parameter");
		student2.display();
		student2.markAttendence();

	}

}
