
//Default and parameterized constructor

package module6;

public class Student {
	
private int rollNo;
private String name;
private double score;


//default constructor

//public Student(){
//	System.out.println("this is default constructor");

//	
//}
public Student() {
rollNo=0;
name="";
score=0.0;
}

//parameterized constructor

//public Student(int rollNo,String name,double score) {
	
//}

public void display() {
	System.out.println("Roll number is: "+rollNo);
	System.out.println("Name is: "+name);
	System.out.println("Score is: "+score);
}

public Student(int rollNo, String name, double score) {
	super();
	this.rollNo = rollNo;
	this.name = name;
	this.score = score;
}


public void markAttendence() {
	System.out.println("Attendence is being marked..");
}

}
