
package module6;

public class GetterSetter {

	private int rollNo;
	private String name;
	private double score;

//default constructor
	public GetterSetter() {
		System.out.println("Default constructor is called...");
		rollNo = 0;
		name = "";
		score = 0.0;
	}

	public int getRollNo() {
		return rollNo;
	}

	public void setRollNo(int rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getScore() {
		return score;
	}

	public void setScore(double score) {
		this.score = score;
	}

//	public void display() {
//		System.out.println("Roll number is: " + rollNo);
//		System.out.println("Name is: " + name);
//		System.out.println("Score is: " + score);
//	}

	public GetterSetter(int rollNo, String name, double score) {
		super();//calls the parent class constructor(object class)
		this.rollNo = rollNo;
		this.name = name;
		this.score = score;
	}

	public void markAttendence() {
		System.out.println("Attendence is being marked..");
	}

}
