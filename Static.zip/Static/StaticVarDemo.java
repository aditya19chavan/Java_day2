package Static;

public class StaticVarDemo {

   static int num=1;
   
   public void display() {
	   num++;
	   System.out.println(num);
   }
   
	public static void main(String[] args) {
		System.out.println(num);                  //1.method to call num    (class level)
		System.out.println(StaticVarDemo.num);   //2.method to call num      
		StaticVarDemo obj=new StaticVarDemo();   //3.method to call num
		obj.display();
	}

}
