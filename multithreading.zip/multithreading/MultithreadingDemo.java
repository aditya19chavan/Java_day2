package multithreading;

class Demo {
	public void fun1() {
		System.out.println("this is fun1");
	}

	public void fun2() {
		System.out.println("this is fun2");
	}
}

class Multithread extends Thread {
	// ch //parent
	Demo demo1 = new Demo();

	public void run() { // run is method of thread which we are overriding
		demo1.fun1();
		demo1.fun2();

		long id = Thread.currentThread().getId();
		String name = Thread.currentThread().getName();
		System.out.println("id is " + id);
		System.out.println("Thread name is" + name);
	}
}

public class MultithreadingDemo {

	public static void main(String[] args) {

//Multithread thread1=new Multithread();
//thread1.start();   //we will call run() method
//System.out.println("=================================");
//
//Multithread thread2=new Multithread();
//thread2.start();
//System.out.println("=================================");
//
//Multithread thread3=new Multithread();
//thread3.start();
//System.out.println("=================================");

		for (int i = 0; i < 5; i++) {
			Multithread thread1 = new Multithread();
			thread1.start();
		}
	}

}
