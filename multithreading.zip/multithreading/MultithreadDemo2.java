package multithreading;

class Multithread2 implements Runnable {

	public void fun1() {
		System.out.println("this is fun1");
	}

	public void fun2() {
		System.out.println("this is fun2");
	}

	public void run() {

		fun1();
		fun2();

	}

}

public class MultithreadDemo2 {

	public static void main(String[] args) {
		Multithread2 obj1 = new Multithread2();
		Thread th1 = new Thread(obj1);
		th1.start();

		System.out.println("id is: " + th1.getId());
		System.out.println("name is: " + th1.getName());

		System.out.println("==============================");

		Multithread2 obj2 = new Multithread2();
		Thread th2 = new Thread(obj2);
		th2.start();

		System.out.println("id is: " + th2.getId());
		System.out.println("name is: " + th2.getName());
		System.out.println("==============================");

		Multithread2 obj3 = new Multithread2();
		Thread th3 = new Thread(obj3);
		th3.start();
		System.out.println("id is: " + th3.getId());
		System.out.println("name is: " + th3.getName());
		System.out.println("==============================");
	}

}
