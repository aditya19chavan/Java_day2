package serialization;

import java.io.FileInputStream;

import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class Employee implements Serializable {
	private int empId;
	private String ename;
	private double salary;

	public Employee(int empId, String ename, double salary) {
		super();
		this.empId = empId;
		this.ename = ename;
		this.salary = salary;
	}

	public int getEmpId() {
		return empId;
	}

	public void setEmpId(int empId) {
		this.empId = empId;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

}

public class DeserializationDemo {

	public static void main(String[] args) {
		Employee emp = new Employee(1, "Adi", 55000);
		try {
			FileOutputStream fileout = new FileOutputStream("D:\\Aditya\\My_File.txt ");
			ObjectOutputStream out = new ObjectOutputStream(fileout);
			out.writeObject(emp);

			FileInputStream fs = new FileInputStream("D:\\Aditya\\My_File.txt ");
			ObjectInputStream in = new ObjectInputStream(fs);
			emp = (Employee) in.readObject();
			in.close();
			fs.close();
			out.close();
			fileout.close();
		} catch (ClassNotFoundException e) {
			System.out.println(e.getMessage());
			e.printStackTrace();

		} catch (Exception e) {
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

		System.out.println("Deserialization is successful....");
		System.out.println("id is: " + emp.getEmpId());
		System.out.println("name is: " + emp.getEname());
		System.out.println("salary is: " + emp.getSalary());
	}

}
