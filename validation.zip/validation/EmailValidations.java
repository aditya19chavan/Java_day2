package validation;
import java.util.Scanner;
public class EmailValidations {

	
	public void checkEmail(String email) {
		int a= email.indexOf("@");
		
		int d=email.lastIndexOf(".");
		System.out.println(a);
		System.out.println(d);
		
		if(a> -1 && d>-1 && a<d)
			System.out.println("valid email id");
		else
			System.out.println("Invalid email id");
	}
	
	
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		EmailValidations emailValidations =new EmailValidations();
		System.out.println("Enter your email id");
		String a=sc.next();
		
		emailValidations.checkEmail(a);
		
		

	}

}
