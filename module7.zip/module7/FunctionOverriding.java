package module7;

class Shape{
	void calArea(String shape, int a, int b) {
		System.out.println("calArea of shape class");
	}
	void display() {
		System.out.println("display the shape class");
	}
	void fun1() {
		System.out.println("fun1 of shape class");
	}
}

 class Rectangle extends Shape{
	void calArea(String shape,int a,int b) {
		System.out.println("Area is "+ (a*b));
	}
	void display() {
//		super.display();
//		super.fun1();
		System.out.println("display of rectangle class");
	}
}

public class FunctionOverriding {

	public static void main(String[] args) {
		Shape shape = new Shape();
		shape.calArea("Shape", 10, 20);
		shape.display();
      
		System.out.println("==========================");
		
		Rectangle rectangle = new Rectangle();
		rectangle.calArea("Rectangle", 10, 20);                             //static binding
		rectangle.display();
		System.out.println("==========================");
		
		shape=new Rectangle();                                             //dynamic binding
		shape.calArea("rect", 11, 22);                                                
		shape.display();
	}

}
