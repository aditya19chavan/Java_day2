package module4;
import java.util.Scanner;
public class Emp {

	private int empNo;
	private String name;
	private double bal;
	
	Scanner sc=new Scanner(System.in);
	
	public void accept() {
		System.out.println("enter the empNo,name,balance");
		empNo=sc.nextInt();
		name=sc.next();
		bal=sc.nextDouble();
	}
	
	
	public void checkEmpNo() {
		if(empNo>0)
			System.out.println("Valid empNo");
		else
			System.out.println("Invalid empNo");
	}
	
	
	public void checkBal() {
		if(bal>0 && bal<100000)
			System.out.println("valid balance");
		else
			System.out.println("Invalid balance");
	}
	
	
	public void display() {
		System.out.println("employee no: " +empNo);
		System.out.println("employee name: " +name);
		System.out.println("bal: " +bal);
	}
}
