package module4;

public class TestEmp {

	public static void main(String[] args) {
		Emp emp=new Emp();
		emp.accept();
		emp.display();
		emp.checkEmpNo();
		emp.checkBal();
	}

}
