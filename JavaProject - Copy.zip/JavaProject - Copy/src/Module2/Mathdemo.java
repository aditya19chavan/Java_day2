package Module2;

public class Mathdemo {
	public static void main(String[] args) {
		
	System.out.println(Math.sqrt(121));
	System.out.println(Math.abs(-22));
	System.out.println(Math.min(303,654));
	System.out.println(Math.max(33, 44));
	System.out.println("random no is: " +Math.random());
	double d=(int)(Math.random()*100);
	System.out.println("d is "+d);
	
	System.out.println(Math.ceil(465.37));
	System.out.println(Math.floor(324.45));
	System.out.println(Math.round(233.78));
	System.out.println(Math.pow(2, 4));
	
	}
}
