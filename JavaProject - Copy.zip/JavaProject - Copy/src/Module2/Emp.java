package Module2;

import java.util.Scanner;
public class Emp {
	
	
	
	private int empNo;
	private String ename;
	private double empSalary;
	Scanner sc=new Scanner(System.in);
	
	public void accept() {
		System.out.println("Enter employee number:");
		empNo=sc.nextInt();
		System.out.println("Employee name:");
		ename=sc.next();
		System.out.println("Enter the salary:");
		empSalary=sc.nextDouble();
		
	}
	public void display() {
		System.out.println("employee number: "+empNo);
		System.out.println("Employee name: "+ename);
		System.out.println("Salary: "+empSalary);
	}
	public void compleProject() {
		System.out.println("Project being completed..");
	}
	public void checkAttendance() {
		System.out.println("Attendence: Present");
	}
	public void applyLoan() {
		System.out.println("Applying for loan");
	}
}
