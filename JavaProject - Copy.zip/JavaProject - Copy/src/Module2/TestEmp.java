package Module2;


public class TestEmp {

	public static void main(String args[]) {
		
		Emp employee=new Emp();
		
		employee.accept();
		employee.display();
		employee.compleProject();
		employee.checkAttendance();
		employee.applyLoan();
		
		System.out.println("==============================");
		System.out.println("Creating second object:");
        Emp employee2=new Emp();
		
		employee2.accept();
		employee2.display();
		employee2.compleProject();
		employee2.checkAttendance();
		employee2.applyLoan();
	}

	}


