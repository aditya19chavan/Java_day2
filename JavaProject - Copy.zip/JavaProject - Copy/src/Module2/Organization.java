package Module2;

import java.util.Scanner;

public class Organization {

	private String name;
	private float turnOver;
	private int totalEmployees;
	private int noOfProducts;
	private int ongoingprojects;

	Scanner sc = new Scanner(System.in);

	public void accept() {
		System.out.println("Enter name of organization: ");
		name = sc.next();

		System.out.println("Enter turn over: ");
		turnOver = sc.nextFloat();

		System.out.println("Total Employees: ");
		totalEmployees = sc.nextInt();

		System.out.println("Enter total products: ");
		noOfProducts = sc.nextInt();
	}

	public void display() {
		System.out.println("name of organization: " + name);
		System.out.println("Enter turn over: " + turnOver);
		System.out.println("Total Employees: " + totalEmployees);
		System.out.println("Enter total products: " + noOfProducts);
	}

	public void toCompleteProjects() {
		System.out.println("All projects are being completed..");
	}

	public void toHireEmployees() {
		System.out.println("Currently hiring..");
	}

	public void expandServices() {
		System.out.println("working on new services that..");
	}

}
