package Module2;

import java.util.Scanner;

public class Student {
	
	private String name;
	private int rollNo;
	private double score;
	
	Scanner sc=new Scanner(System.in);
	
	public void attendclass() {
		System.out.println("attending the class");
	}
	public void apperExam() {
		System.out.println("appearing for the exam..");
	}
	
	public void completeAssignment() {
		System.out.println("completing the assignments");
	}
	
	public void display() {
		System.out.println("Name: "+name);
		System.out.println("RollNo: "+rollNo);
		System.out.println("Score: "+score);
	}
	public void accept() {
		System.out.println("enter the rollno");
		rollNo=sc.nextInt();
		System.out.println("enter the name");
		name=sc.next();
		System.out.println("enter score");
		score=sc.nextDouble();
	}
	
public static void main(String args[]) {
	System.out.println("creating an object");
    Student student = new Student(); 
    
      student.name="Aditya";
  	  student.rollNo=12;
  	  student.score=89.60;
  	  
  	  
  	  System.out.println("calling the member functions");
  	 
  	   student.attendclass();
  	   student.apperExam();
  	   student.completeAssignment();
  	   student.display();
	
	
}
}
