package Module2;

public class TestOrg {
	public static void main(String args[]) {
	Organization org1=new Organization();
	
	 org1.accept();
	 org1.display();
	 org1.toCompleteProjects();
	 org1.toHireEmployees();
	 org1.expandServices();
	}
}
