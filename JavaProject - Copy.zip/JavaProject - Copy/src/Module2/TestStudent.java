package Module2;

public class TestStudent {
	
	public static void main(String args[]) {
		System.out.println("Creating first object");
	Student student = new Student();
	//student.accept();
	student.display();
	
	System.out.println("Creating second object");
	Student student2=new Student();
	student2.accept();
	student2.display();
	}
}
