package module1;

public class Student {

	private String name;
	private int rollNo;
	private double score;
	
	
	public void attendclass() {
		System.out.println("attending the class");
	}
	public void apperExam() {
		System.out.println("appearing for the exam..");
	}
	
	public void completeAssignment() {
		System.out.println("completing the assignments");
	}
	
	public void show() {
		System.out.println("Name: "+name);
		System.out.println("RollNo: "+rollNo);
		System.out.println("Score: "+score);
	}
	
	
	
	
	public static void main(String[] args) {
	System.out.println("creating an object");
      Student student = new Student(); 
      
          student.name="Aditya";
    	  student.rollNo=12;
    	  student.score=89.60;
    	  
    	  
    	  System.out.println("calling the member functions");
    	 
    	   student.attendclass();
    	   student.apperExam();
    	   student.completeAssignment();
    	   student.show();
    	  
      }
	}


