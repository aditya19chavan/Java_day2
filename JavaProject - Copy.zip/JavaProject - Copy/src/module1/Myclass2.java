package module1;

public class Myclass2 {
	public static void main(String[] args) {
		int empno=100;
		String ename="Aditya";
		double sal=30000.50;
		float comm=1000.56f;
		float bonus=(float)500.55;
		byte b=100;
		short s=2000;
		long l=9745446799665l;
		char gender='M';
		boolean passStatus=true;
		
		System.out.println("empno="+empno);
		System.out.println("ename="+ename);
		System.out.println("salary="+sal);
		System.out.println("comm="+comm);
		System.out.println("bonus="+bonus);
		System.out.println("byte="+b);
		System.out.println("short="+s);
		System.out.println("long="+l);
		System.out.println("gender="+gender);
		System.out.println("passStatus="+passStatus);
	}
}
