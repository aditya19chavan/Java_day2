package module1;

public class Organization {

	private String name;
	private float turnOver;
	private int totalEmployees;
	private int noOfProducts;
	private int ongoingprojects;
	
	
	public void toCompleteProjects() {
		System.out.println("All projects are being completed..");
	}
	public void toHireEmployees() {
		System.out.println("Currently hiring..");
	}
	
	public void expandServices() {
		System.out.println("working on new services that..");
	}
	
	public void display_Status() {
		System.out.println("Name: "+name);
		System.out.println("Employee count: "+totalEmployees);
		System.out.println("Total Products: "+noOfProducts);
		System.out.println("Total on going projects: "+ongoingprojects);
	}
	
	
	public static void main(String[] args) {
	
		Organization org=new Organization();   //object formation
		
          org.name="Aditya Enterprises";
          org.totalEmployees=123;
          org.noOfProducts=17;
          org.ongoingprojects=15;
          
          
          System.out.println("Organizational 2024 Sept report: ");
          System.out.println("==================================");
          org.display_Status();
          org.toCompleteProjects();
          org.toHireEmployees();
          org.expandServices();
}
}
