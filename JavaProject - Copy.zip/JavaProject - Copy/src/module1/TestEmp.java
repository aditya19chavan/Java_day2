package module1;

import Module2.Emp;

public class TestEmp {

	public static void main(String[] args) {
		Emp employee = new Emp();
		employee.accept();
		employee.display();
		employee.checkAttendance();
		employee.compleProject();
		employee.applyLoan();
	}

}
