package module3;

public class DoWhileDemo {

	public static void main(String[] args) {
		int b =1;
		do {
			System.out.println(b);
			b++;
		}while(b<0);

	}

}
