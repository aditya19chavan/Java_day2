package module3;

public class OddDemo {
	public static void main(String[] args) {
		
	
		int n = 1;

		while(n<=20) {
			if(n%2!=0) {
	
				System.out.println("oddnumbers are"+n);
				
			}
			n++;
		}
	}
}
