package module3;
import java.util.Scanner;
public class IfDemo5 {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	int m;
	int power;
	System.out.println("Enter the number");
	int n=sc.nextInt();
	
	m=n%10;
	n=n/10;
	System.out.println(Math.pow(m, n));

	
	}

}
