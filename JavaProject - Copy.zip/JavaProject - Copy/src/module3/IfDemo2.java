package module3;

import java.util.Scanner;

public class IfDemo2 {

	public static void main(String args[]) {

		Scanner sc = new Scanner(System.in);
		System.out.println("enter a number1");
		int num1 = sc.nextInt();
		System.out.println("enter a number2");
		int num2 = sc.nextInt();

		if (num1 > num2) {
			System.out.println("num1 is greatest: " + num1);
		} else if (num1 == num2) {
			System.out.println("Both numbers are equal..");
		} else {
			System.out.println("num2 is greatest: " + num2);
		}
	}
}