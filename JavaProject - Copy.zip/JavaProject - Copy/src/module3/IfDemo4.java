package module3;

import java.util.Scanner;

public class IfDemo4 {

	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter number ");
		int num = sc.nextInt();

		if (num > 0 && num < 10) {
			System.out.println("Number is 1 digit");
		} else if (num >= 10 && num < 100) {
			System.out.println("Number is 2 digit");
		} else if (num >= 100 && num < 1000) {
			System.out.println("Number is 3 digit");
		} else {
			System.out.println("Number is more than 3 digit");
		}

	}

}
