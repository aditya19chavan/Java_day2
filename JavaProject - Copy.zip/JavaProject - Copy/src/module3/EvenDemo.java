package module3;

public class EvenDemo {
	public static void main(String[] args) {
		int a=1;
		while(a<=20) {
			if(a%2 == 0)
				System.out.println(a);
			a++;
		}
	}
}
