package module3;

public class WhileDemo {
	public static void main(String[] args) {
		int a=1;
		while(a<=10) {
			System.out.println(a);
		}
	}
}
