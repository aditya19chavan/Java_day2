package fileio;

import java.io.FileInputStream;
import java.io.IOException;

public class CheckExceptionDemo1 {

	public static void main(String[] args) {
		try {

			FileInputStream fis = new FileInputStream("D:\\Aditya\\MyFile1.txt");
			int k;
			// read() :read a character
			while ((k = fis.read()) != -1) {
				System.out.print((char) k);
			}
			fis.close();
		} catch (IOException e) {
			System.out.println("The path of the file is wrongly given");
			System.out.println(e.getMessage());
		}
	}
}