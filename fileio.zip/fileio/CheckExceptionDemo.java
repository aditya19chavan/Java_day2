package fileio;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class CheckExceptionDemo {

	public static void main(String[] args) throws IOException {
		FileInputStream fis = new FileInputStream("D:\\Aditya\\MyFile.txt");
		int k;
		//read() :read a character
		while ((k = fis.read()) != -1) {
			System.out.print((char) k);
		}
		fis.close();
	}

}
